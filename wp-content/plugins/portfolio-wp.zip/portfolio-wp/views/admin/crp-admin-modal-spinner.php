<div id="crp-spinner-background">
</div>

<div id="crp-spinner">
</div>