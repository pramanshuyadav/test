<?php 
$themeDetails['name'] 			= 'Default';
$themeDetails['folder_name'] 	= 'default';
$themeDetails['demo_url'] 		= 'http://www.masonrylayout.com/masonry-theme-demo/default/';
?>