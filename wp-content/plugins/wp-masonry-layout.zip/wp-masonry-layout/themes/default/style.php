<style>
.wmle_container .wmle_item{border:1px solid #e5e5e5; margin:5px; padding:5px;-webkit-box-shadow: 0px 0px 3px -1px #959595;
box-shadow: 0px 0px 3px -1px #959595;}
.wmle_container .wmle_item .wpme_image{ text-align:center;}
.wmle_container .wmle_item .wpme_image img{border-radius:0px !important; box-shadow:none !important;}
.wmle_container .wmle_item .wmle_post_meta{color:#a5a4a2; font-size:11px;line-height:1.5; padding-bottom:6px;}
.wmle_container .wmle_item .wmle_post_meta a{ color:inherit; text-decoration:none;}
.wmle_container .wmle_item .wmle_post_meta a:hover{ text-decoration:underline;}
.wmle_container .wmle_item .wmle_post_title{ font-size:12px; color:#a5a4a2; line-height:1.5; padding-bottom:6px;border-bottom:1px solid #f1f1f1; border-top:1px solid #f1f1f1; padding-top:5px; padding-bottom:5px; font-weight:bold;}
.wmle_container .wmle_item .wmle_post_title a{ color:inherit; text-decoration:none;}
.wmle_container .wmle_item .wmle_post_excerpt{font-size:12px; color:#a5a4a2; padding-top:10px; padding-bottom:10px;}
.wmle_container .wmle_item .wmle_post_excerpt p{ line-height:1.5;}
.wmle_container .wmle_item .wmle_post_excerpt p:last-child{ padding-bottom:0px; margin-bottom:0px;}
.wmle_loadmore .wmle_loadmore_btn{ display:inline-block; padding:5px 15px;border:1px solid #e5e5e5; margin:5px;-webkit-box-shadow: 0px 0px 3px -1px #959595;box-shadow: 0px 0px 3px -1px #959595; color:#454545; text-decoration:none;-webkit-border-radius: 4px;border-radius: 4px;}
</style>